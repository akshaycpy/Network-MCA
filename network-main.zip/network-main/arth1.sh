read -p"enter the value of i:" i
read -p"enter the value of j:" j
echo "addition of $i+$j is =" $((i+j))
echo "subtraction of $i-$j is =" $((i-j))
echo "multiplication of $i*$j is =" $((i*j))
echo "division of $i/$j is =" $((i/j))
echo "modulus of $i%$j is =" $((i%j))
