printf "\nprint data on myFile use tabs to seperate\n";
cat myFile | column -t -s ' ';


