printf "\nprint first 2 row only\n";
head -n 2 myFile;

