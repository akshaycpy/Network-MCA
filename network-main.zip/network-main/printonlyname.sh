
printf "\nprint only names\n"
cut -d " " -f 2 myFile;
