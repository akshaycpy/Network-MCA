
printf "\nprint word count, lines count, letter count\n"
cut -d " " -f 2 myFile | wc;
