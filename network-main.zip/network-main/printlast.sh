printf "\n print last row\n";
head -n 3 myFile | tail -n 1;

