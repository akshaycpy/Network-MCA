printf "\nFile content :\n";
cat >myFile;


